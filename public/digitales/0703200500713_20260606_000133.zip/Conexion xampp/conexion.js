const mysql = require("mysql");

// Configuración de la conexión
const conexion = mysql.createConnection({
    host: "localhost",
    port: 3306,  // Cambiado a número (sin comillas)
    database: "matricula",
    user: "root",
    password: '',
    insecureAuth: true  // Para compatibilidad con versiones antiguas de MySQL
});

// Manejo de conexión con reintentos
const handleConnection = () => {
    conexion.connect((error) => {
        if (error) {
            console.error("Error de conexión a MySQL:", error);
            // Reintenta después de 2 segundos
            setTimeout(handleConnection, 2000);
        } else {
            console.log("✅ Conexión exitosa a MySQL");
        }
    });
};

// Iniciar conexión
handleConnection();

// Exportar la conexión para usarla en otros archivos
module.exports = conexion;