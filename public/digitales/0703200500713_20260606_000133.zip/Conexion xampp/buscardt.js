function buscarAlumno() {
    const id = document.getElementById('buscarID').value;
    fetch(`/buscar-matricula?ID_estudiante=${id}`)
        .then(res => res.json())
        .then(data => {
            const mensaje = document.getElementById('mensajeBusqueda');
            const tabla = document.getElementById('tablaResultado');
            const cuerpo = document.getElementById('resultadoBody');

            cuerpo.innerHTML = '';

            if (data.length === 0) {
                mensaje.innerText = 'Alumno no encontrado';
                tabla.style.display = 'none';
                return;
            }

            const alumno = data[0];
            const fila = `
                <tr>
                    <td>${alumno.ID_estudiante}</td>
                    <td>${alumno.Nombre_estudiante}</td>
                    <td>${alumno.Curso}</td>
                    <td>${alumno.Registro}</td>
                </tr>
            `;
            cuerpo.innerHTML = fila;
            tabla.style.display = 'table';
            mensaje.innerText = '';
        })
        .catch(err => {
            console.error('Error:', err);
            document.getElementById('mensajeBusqueda').innerText = 'Error al buscar el alumno';
            document.getElementById('tablaResultado').style.display = 'none';
        });
}