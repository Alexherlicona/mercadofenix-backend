const express = require("express");
const bodyParser = require("body-parser");
const conexion = require("./conexion");

const app = express();

// Middleware para verificar conexión a la base de datos (CORREGIDO)
app.use((req, res, next) => {
  // Verificar si la conexión está activa
  if (conexion.state === 'disconnected') {
    console.error('Error: Conexión a la base de datos perdida');
    return res.status(503).json({ error: 'Servicio no disponible. Error de base de datos' });
  }
  
  // Para una conexión simple, no necesitamos getConnection()
  // Simplemente verificamos el estado de la conexión
  if (conexion.state === 'authenticated') {
    next();
  } else {
    console.error('Estado de conexión:', conexion.state);
    // Intentar reconectar
    conexion.connect((err) => {
      if (err) {
        return res.status(503).json({ error: 'Base de datos no disponible' });
      }
      next();
    });
  }
});

// Configuración de middlewares
app.use(express.static(__dirname));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.json());

// Ruta principal
app.get("/", (req, res) => {
  res.sendFile(__dirname + "/indexdt.html");
});

// Ruta de prueba para verificar conexión a la base de datos
app.get("/test-connection", (req, res) => {
  conexion.query("SELECT 1 + 1 AS solution", (err, results) => {
    if (err) {
      console.error("Error en test-connection:", err);
      return res.status(500).json({ 
        connected: false, 
        error: "Error de conexión a la base de datos",
        details: err.message 
      });
    }
    res.json({ 
      connected: true,
      message: "Conexión a MySQL exitosa",
      solution: results[0].solution 
    });
  });
});

// ==================== RUTAS PARA ASIGNATURA ====================
app.post("/registrar_asignatura", (req, res) => {
  const { id_asignatura, nom_asignatura, grados_que_cubre } = req.body;
  
  if (!id_asignatura || !nom_asignatura || !grados_que_cubre) {
    return res.status(400).json({ error: "Datos incompletos" });
  }

  const sql = `INSERT INTO asignatura (id_asignatura, nom_asignatura, grados_que_cubre) VALUES (?, ?, ?)`;
  
  conexion.query(sql, [id_asignatura, nom_asignatura, grados_que_cubre], (err, result) => {
    if (err) {
      console.error("Error en registrar_asignatura:", err);
      return res.status(500).json({ error: "Error al registrar asignatura", details: err.message });
    }
    res.json({ success: true, message: "Asignatura registrada con éxito" });
  });
});

app.post("/eliminar_asignatura", (req, res) => {
  const { id_asignatura } = req.body;
  
  if (!id_asignatura) {
    return res.status(400).json({ error: "ID de asignatura requerido" });
  }

  const sql = "DELETE FROM asignatura WHERE id_asignatura = ?";
  
  conexion.query(sql, [id_asignatura], (err, result) => {
    if (err) {
      console.error("Error en eliminar_asignatura:", err);
      return res.status(500).json({ error: "Error al eliminar la asignatura", details: err.message });
    }
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: "No se encontró la asignatura para eliminar" });
    }
    
    res.json({ success: true, message: "Asignatura eliminada con éxito" });
  });
});

app.post("/modificar_asignatura", (req, res) => {
  const { id_asignatura, nom_asignatura, grados_que_cubre } = req.body;
  
  if (!id_asignatura || !nom_asignatura || !grados_que_cubre) {
    return res.status(400).json({ error: "Datos incompletos" });
  }

  const sql = `UPDATE asignatura SET nom_asignatura = ?, grados_que_cubre = ? WHERE id_asignatura = ?`;
  
  conexion.query(sql, [nom_asignatura, grados_que_cubre, id_asignatura], (err, result) => {
    if (err) {
      console.error("Error en modificar_asignatura:", err);
      return res.status(500).json({ error: "Error al modificar la asignatura", details: err.message });
    }
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: "No se encontró la asignatura para modificar" });
    }
    
    res.json({ success: true, message: "Asignatura modificada con éxito" });
  });
});

app.get("/buscar_asignatura", (req, res) => {
  const { id_asignatura } = req.query;
  
  if (!id_asignatura) {
    return res.status(400).json({ error: "ID de asignatura requerido" });
  }

  const sql = "SELECT * FROM asignatura WHERE id_asignatura = ?";
  
  conexion.query(sql, [id_asignatura], (err, results) => {
    if (err) {
      console.error("Error en buscar_asignatura:", err);
      return res.status(500).json({ error: "Error al buscar la asignatura", details: err.message });
    }
    
    if (results.length === 0) {
      return res.status(404).json({ error: "Asignatura no encontrada" });
    }
    
    res.json({ success: true, data: results[0] });
  });
});

// ==================== RUTAS PARA DOCENTE ====================
app.post("/registrar_docente", (req, res) => {
  const { id_docente, nombre_completo, id_asignatura, grados_que_imparte, telefono, direccion } = req.body;
  
  if (!id_docente || !nombre_completo || !id_asignatura || !grados_que_imparte || !telefono || !direccion) {
    return res.status(400).json({ error: "Datos incompletos" });
  }

  const sql = `INSERT INTO docente (id_docente, nombre_completo, id_asignatura, grados_que_imparte, telefono, direccion) VALUES (?, ?, ?, ?, ?, ?)`;
  
  conexion.query(sql, [id_docente, nombre_completo, id_asignatura, grados_que_imparte, telefono, direccion], (err, result) => {
    if (err) {
      console.error("Error en registrar_docente:", err);
      return res.status(500).json({ error: "Error al registrar docente", details: err.message });
    }
    res.json({ success: true, message: "Docente registrado con éxito" });
  });
});

app.post("/eliminar_docente", (req, res) => {
  const { id_docente } = req.body;
  
  if (!id_docente) {
    return res.status(400).json({ error: "ID de docente requerido" });
  }

  const sql = "DELETE FROM docente WHERE id_docente = ?";
  
  conexion.query(sql, [id_docente], (err, result) => {
    if (err) {
      console.error("Error en eliminar_docente:", err);
      return res.status(500).json({ error: "Error al eliminar el docente", details: err.message });
    }
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: "No se encontró el docente para eliminar" });
    }
    
    res.json({ success: true, message: "Docente eliminado con éxito" });
  });
});

app.post("/modificar_docente", (req, res) => {
  const { id_docente, nombre_completo, id_asignatura, grados_que_imparte, telefono, direccion } = req.body;
  
  if (!id_docente || !nombre_completo || !id_asignatura || !grados_que_imparte || !telefono || !direccion) {
    return res.status(400).json({ error: "Datos incompletos" });
  }

  const sql = `UPDATE docente SET nombre_completo = ?, id_asignatura = ?, grados_que_imparte = ?, telefono = ?, direccion = ? WHERE id_docente = ?`;
  
  conexion.query(sql, [nombre_completo, id_asignatura, grados_que_imparte, telefono, direccion, id_docente], (err, result) => {
    if (err) {
      console.error("Error en modificar_docente:", err);
      return res.status(500).json({ error: "Error al modificar el docente", details: err.message });
    }
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: "No se encontró el docente para modificar" });
    }
    
    res.json({ success: true, message: "Docente modificado con éxito" });
  });
});

app.get("/buscar_docente", (req, res) => {
  const { id_docente } = req.query;
  
  if (!id_docente) {
    return res.status(400).json({ error: "ID de docente requerido" });
  }

  const sql = "SELECT * FROM docente WHERE id_docente = ?";
  
  conexion.query(sql, [id_docente], (err, results) => {
    if (err) {
      console.error("Error en buscar_docente:", err);
      return res.status(500).json({ error: "Error al buscar el docente", details: err.message });
    }
    
    if (results.length === 0) {
      return res.status(404).json({ error: "Docente no encontrado" });
    }
    
    res.json({ success: true, data: results[0] });
  });
});

// ==================== RUTAS PARA ESTUDIANTE ====================
app.post("/registrar_estudiante", (req, res) => {
  const { DNI_estudiante, nombre_completo, asignatura, grado, grupo, instituto, edad, encargado } = req.body;
  
  if (!DNI_estudiante || !nombre_completo || !asignatura || !grado || !grupo || !instituto || !edad || !encargado) {
    return res.status(400).json({ error: "Datos incompletos" });
  }

  const sql = `INSERT INTO estudiante (DNI_estudiante, nombre_completo, asignatura, grado, grupo, instituto, edad, encargado) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;
  
  conexion.query(sql, [DNI_estudiante, nombre_completo, asignatura, grado, grupo, instituto, edad, encargado], (err, result) => {
    if (err) {
      console.error("Error en registrar_estudiante:", err);
      return res.status(500).json({ error: "Error al registrar estudiante", details: err.message });
    }
    res.json({ success: true, message: "Estudiante registrado con éxito" });
  });
});

app.post("/eliminar_estudiante", (req, res) => {
  const { DNI_estudiante } = req.body;
  
  if (!DNI_estudiante) {
    return res.status(400).json({ error: "DNI de estudiante requerido" });
  }

  const sql = "DELETE FROM estudiante WHERE DNI_estudiante = ?";
  
  conexion.query(sql, [DNI_estudiante], (err, result) => {
    if (err) {
      console.error("Error en eliminar_estudiante:", err);
      return res.status(500).json({ error: "Error al eliminar el estudiante", details: err.message });
    }
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: "No se encontró el estudiante para eliminar" });
    }
    
    res.json({ success: true, message: "Estudiante eliminado con éxito" });
  });
});

app.post("/modificar_estudiante", (req, res) => {
  const { DNI_estudiante, nombre_completo, asignatura, grado, grupo, instituto, edad, encargado } = req.body;
  
  if (!DNI_estudiante || !nombre_completo || !asignatura || !grado || !grupo || !instituto || !edad || !encargado) {
    return res.status(400).json({ error: "Datos incompletos" });
  }

  const sql = `UPDATE estudiante SET nombre_completo = ?, asignatura = ?, grado = ?, grupo = ?, instituto = ?, edad = ?, encargado = ? WHERE DNI_estudiante = ?`;
  
  conexion.query(sql, [nombre_completo, asignatura, grado, grupo, instituto, edad, encargado, DNI_estudiante], (err, result) => {
    if (err) {
      console.error("Error en modificar_estudiante:", err);
      return res.status(500).json({ error: "Error al modificar el estudiante", details: err.message });
    }
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: "No se encontró el estudiante para modificar" });
    }
    
    res.json({ success: true, message: "Estudiante modificado con éxito" });
  });
});

app.get("/buscar_estudiante", (req, res) => {
  const { DNI_estudiante } = req.query;
  
  if (!DNI_estudiante) {
    return res.status(400).json({ error: "DNI de estudiante requerido" });
  }

  const sql = "SELECT * FROM estudiante WHERE DNI_estudiante = ?";
  
  conexion.query(sql, [DNI_estudiante], (err, results) => {
    if (err) {
      console.error("Error en buscar_estudiante:", err);
      return res.status(500).json({ error: "Error al buscar el estudiante", details: err.message });
    }
    
    if (results.length === 0) {
      return res.status(404).json({ error: "Estudiante no encontrado" });
    }
    
    res.json({ success: true, data: results[0] });
  });
});

// Ruta para obtener todos los estudiantes (útil para pruebas)
app.get("/estudiantes", (req, res) => {
  const sql = "SELECT * FROM estudiante LIMIT 10";
  
  conexion.query(sql, (err, results) => {
    if (err) {
      console.error("Error en /estudiantes:", err);
      return res.status(500).json({ error: "Error al obtener estudiantes", details: err.message });
    }
    
    res.json({ success: true, data: results });
  });
});

// Manejador de errores global
app.use((err, req, res, next) => {
  console.error("Error no manejado:", err);
  res.status(500).json({ error: "Error interno del servidor", details: err.message });
});

// Manejar rutas no encontradas
app.use((req, res) => {
  res.status(404).json({ error: "Ruta no encontrada" });
});

// Iniciar servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor iniciado en http://localhost:${PORT}`);
  console.log(`Para probar la conexión a la base de datos, visita: http://localhost:${PORT}/test-connection`);
});